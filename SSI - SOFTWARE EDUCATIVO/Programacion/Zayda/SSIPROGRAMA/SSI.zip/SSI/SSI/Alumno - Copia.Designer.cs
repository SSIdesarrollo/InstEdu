﻿namespace SSI
{
    partial class frmPersonal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblnombrealumno = new System.Windows.Forms.Label();
            this.lblapellidoalumno = new System.Windows.Forms.Label();
            this.txbnombrealumno = new System.Windows.Forms.TextBox();
            this.txbapellidoalumno = new System.Windows.Forms.TextBox();
            this.lblfechanacimiento = new System.Windows.Forms.Label();
            this.lblslash1 = new System.Windows.Forms.Label();
            this.lblslash2 = new System.Windows.Forms.Label();
            this.btnSalirPersonal = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnnuevopersonal = new System.Windows.Forms.Button();
            this.btneditarpersonal = new System.Windows.Forms.Button();
            this.btnguardarpersonal = new System.Windows.Forms.Button();
            this.btnbuscarpersonal = new System.Windows.Forms.Button();
            this.btneliminarpersonal = new System.Windows.Forms.Button();
            this.btnInscripcion = new System.Windows.Forms.Button();
            this.btnReinscripcion = new System.Windows.Forms.Button();
            this.lblcarne = new System.Windows.Forms.Label();
            this.txbrama = new System.Windows.Forms.TextBox();
            this.txbaño = new System.Windows.Forms.TextBox();
            this.txbcarnet = new System.Windows.Forms.TextBox();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.cmbdia = new System.Windows.Forms.ComboBox();
            this.cmbmes = new System.Windows.Forms.ComboBox();
            this.cmbaño = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnnuevopersonal);
            this.panel1.Controls.Add(this.btneditarpersonal);
            this.panel1.Controls.Add(this.btnguardarpersonal);
            this.panel1.Controls.Add(this.btnbuscarpersonal);
            this.panel1.Controls.Add(this.btneliminarpersonal);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(326, 100);
            this.panel1.TabIndex = 5;
            // 
            // lblnombrealumno
            // 
            this.lblnombrealumno.AutoSize = true;
            this.lblnombrealumno.Font = new System.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnombrealumno.Location = new System.Drawing.Point(22, 188);
            this.lblnombrealumno.Name = "lblnombrealumno";
            this.lblnombrealumno.Size = new System.Drawing.Size(155, 21);
            this.lblnombrealumno.TabIndex = 6;
            this.lblnombrealumno.Text = "Nombres Alumno:";
            this.lblnombrealumno.Visible = false;
            // 
            // lblapellidoalumno
            // 
            this.lblapellidoalumno.AutoSize = true;
            this.lblapellidoalumno.Font = new System.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblapellidoalumno.Location = new System.Drawing.Point(22, 236);
            this.lblapellidoalumno.Name = "lblapellidoalumno";
            this.lblapellidoalumno.Size = new System.Drawing.Size(155, 21);
            this.lblapellidoalumno.TabIndex = 7;
            this.lblapellidoalumno.Text = "Apellidos Alumno:";
            this.lblapellidoalumno.Visible = false;
            // 
            // txbnombrealumno
            // 
            this.txbnombrealumno.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbnombrealumno.Location = new System.Drawing.Point(192, 188);
            this.txbnombrealumno.Name = "txbnombrealumno";
            this.txbnombrealumno.Size = new System.Drawing.Size(548, 25);
            this.txbnombrealumno.TabIndex = 8;
            this.txbnombrealumno.Visible = false;
            // 
            // txbapellidoalumno
            // 
            this.txbapellidoalumno.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbapellidoalumno.Location = new System.Drawing.Point(192, 236);
            this.txbapellidoalumno.Name = "txbapellidoalumno";
            this.txbapellidoalumno.Size = new System.Drawing.Size(548, 25);
            this.txbapellidoalumno.TabIndex = 9;
            this.txbapellidoalumno.Visible = false;
            // 
            // lblfechanacimiento
            // 
            this.lblfechanacimiento.AutoSize = true;
            this.lblfechanacimiento.Font = new System.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfechanacimiento.Location = new System.Drawing.Point(22, 287);
            this.lblfechanacimiento.Name = "lblfechanacimiento";
            this.lblfechanacimiento.Size = new System.Drawing.Size(188, 21);
            this.lblfechanacimiento.TabIndex = 10;
            this.lblfechanacimiento.Text = "Fecha De Nacimiento:";
            this.lblfechanacimiento.Visible = false;
            // 
            // lblslash1
            // 
            this.lblslash1.AutoSize = true;
            this.lblslash1.Font = new System.Drawing.Font("Berlin Sans FB", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblslash1.Location = new System.Drawing.Point(294, 276);
            this.lblslash1.Name = "lblslash1";
            this.lblslash1.Size = new System.Drawing.Size(29, 41);
            this.lblslash1.TabIndex = 14;
            this.lblslash1.Text = "/";
            this.lblslash1.Visible = false;
            // 
            // lblslash2
            // 
            this.lblslash2.AutoSize = true;
            this.lblslash2.Font = new System.Drawing.Font("Berlin Sans FB", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblslash2.Location = new System.Drawing.Point(500, 276);
            this.lblslash2.Name = "lblslash2";
            this.lblslash2.Size = new System.Drawing.Size(29, 41);
            this.lblslash2.TabIndex = 15;
            this.lblslash2.Text = "/";
            this.lblslash2.Visible = false;
            // 
            // btnSalirAlumno
            // 
            this.btnSalirPersonal.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirPersonal.Location = new System.Drawing.Point(670, 521);
            this.btnSalirPersonal.Name = "btnSalirAlumno";
            this.btnSalirPersonal.Size = new System.Drawing.Size(100, 40);
            this.btnSalirPersonal.TabIndex = 17;
            this.btnSalirPersonal.Text = "Salir";
            this.btnSalirPersonal.UseVisualStyleBackColor = true;
            this.btnSalirPersonal.Click += new System.EventHandler(this.button6_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SSI.Properties.Resources.InstEdu_sin_fondo;
            this.pictureBox1.Location = new System.Drawing.Point(603, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(190, 118);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // btnnuevo
            // 
            this.btnnuevopersonal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnnuevopersonal.Image = global::SSI.Properties.Resources._new;
            this.btnnuevopersonal.Location = new System.Drawing.Point(22, 24);
            this.btnnuevopersonal.Name = "btnnuevo";
            this.btnnuevopersonal.Size = new System.Drawing.Size(52, 52);
            this.btnnuevopersonal.TabIndex = 2;
            this.btnnuevopersonal.UseVisualStyleBackColor = true;
            // 
            // btneditar
            // 
            this.btneditarpersonal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btneditarpersonal.Image = global::SSI.Properties.Resources.edit2;
            this.btneditarpersonal.Location = new System.Drawing.Point(80, 24);
            this.btneditarpersonal.Name = "btneditar";
            this.btneditarpersonal.Size = new System.Drawing.Size(52, 52);
            this.btneditarpersonal.TabIndex = 4;
            this.btneditarpersonal.UseVisualStyleBackColor = true;
            // 
            // btnguardar
            // 
            this.btnguardarpersonal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnguardarpersonal.Image = global::SSI.Properties.Resources.save;
            this.btnguardarpersonal.Location = new System.Drawing.Point(138, 24);
            this.btnguardarpersonal.Name = "btnguardar";
            this.btnguardarpersonal.Size = new System.Drawing.Size(52, 52);
            this.btnguardarpersonal.TabIndex = 0;
            this.btnguardarpersonal.UseVisualStyleBackColor = true;
            this.btnguardarpersonal.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnbuscar
            // 
            this.btnbuscarpersonal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnbuscarpersonal.Image = global::SSI.Properties.Resources.search;
            this.btnbuscarpersonal.Location = new System.Drawing.Point(254, 24);
            this.btnbuscarpersonal.Name = "btnbuscar";
            this.btnbuscarpersonal.Size = new System.Drawing.Size(52, 52);
            this.btnbuscarpersonal.TabIndex = 3;
            this.btnbuscarpersonal.UseVisualStyleBackColor = true;
            // 
            // btneliminar
            // 
            this.btneliminarpersonal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btneliminarpersonal.Image = global::SSI.Properties.Resources.error;
            this.btneliminarpersonal.Location = new System.Drawing.Point(196, 24);
            this.btneliminarpersonal.Name = "btneliminar";
            this.btneliminarpersonal.Size = new System.Drawing.Size(52, 52);
            this.btneliminarpersonal.TabIndex = 1;
            this.btneliminarpersonal.UseVisualStyleBackColor = true;
            // 
            // btnInscripcion
            // 
            this.btnInscripcion.BackColor = System.Drawing.Color.Gray;
            this.btnInscripcion.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInscripcion.Location = new System.Drawing.Point(437, 21);
            this.btnInscripcion.Name = "btnInscripcion";
            this.btnInscripcion.Size = new System.Drawing.Size(126, 40);
            this.btnInscripcion.TabIndex = 18;
            this.btnInscripcion.Text = "Inscripción";
            this.btnInscripcion.UseVisualStyleBackColor = false;
            this.btnInscripcion.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnReinscripcion
            // 
            this.btnReinscripcion.BackColor = System.Drawing.Color.Gray;
            this.btnReinscripcion.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReinscripcion.Location = new System.Drawing.Point(437, 67);
            this.btnReinscripcion.Name = "btnReinscripcion";
            this.btnReinscripcion.Size = new System.Drawing.Size(126, 40);
            this.btnReinscripcion.TabIndex = 19;
            this.btnReinscripcion.Text = "Reinscripción";
            this.btnReinscripcion.UseVisualStyleBackColor = false;
            this.btnReinscripcion.Click += new System.EventHandler(this.button8_Click);
            // 
            // lblcarne
            // 
            this.lblcarne.AutoSize = true;
            this.lblcarne.Font = new System.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcarne.Location = new System.Drawing.Point(22, 144);
            this.lblcarne.Name = "lblcarne";
            this.lblcarne.Size = new System.Drawing.Size(119, 21);
            this.lblcarne.TabIndex = 20;
            this.lblcarne.Text = "N# de Carné:";
            this.lblcarne.Visible = false;
            // 
            // txbrama
            // 
            this.txbrama.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbrama.Location = new System.Drawing.Point(158, 143);
            this.txbrama.Name = "txbrama";
            this.txbrama.Size = new System.Drawing.Size(61, 25);
            this.txbrama.TabIndex = 21;
            this.txbrama.Visible = false;
            // 
            // txbaño
            // 
            this.txbaño.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbaño.Location = new System.Drawing.Point(229, 143);
            this.txbaño.Name = "txbaño";
            this.txbaño.Size = new System.Drawing.Size(61, 25);
            this.txbaño.TabIndex = 22;
            this.txbaño.Visible = false;
            // 
            // txbcarnet
            // 
            this.txbcarnet.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbcarnet.Location = new System.Drawing.Point(301, 143);
            this.txbcarnet.Name = "txbcarnet";
            this.txbcarnet.Size = new System.Drawing.Size(61, 25);
            this.txbcarnet.TabIndex = 23;
            this.txbcarnet.Visible = false;
            // 
            // btnConsultar
            // 
            this.btnConsultar.BackColor = System.Drawing.Color.Gray;
            this.btnConsultar.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultar.Location = new System.Drawing.Point(437, 133);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(126, 40);
            this.btnConsultar.TabIndex = 24;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = false;
            this.btnConsultar.Visible = false;
            // 
            // cmbdia
            // 
            this.cmbdia.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdia.FormattingEnabled = true;
            this.cmbdia.Location = new System.Drawing.Point(227, 284);
            this.cmbdia.Name = "cmbdia";
            this.cmbdia.Size = new System.Drawing.Size(63, 26);
            this.cmbdia.TabIndex = 25;
            this.cmbdia.Visible = false;
            // 
            // cmbmes
            // 
            this.cmbmes.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbmes.FormattingEnabled = true;
            this.cmbmes.Location = new System.Drawing.Point(329, 284);
            this.cmbmes.Name = "cmbmes";
            this.cmbmes.Size = new System.Drawing.Size(166, 26);
            this.cmbmes.TabIndex = 26;
            this.cmbmes.Visible = false;
            // 
            // cmbaño
            // 
            this.cmbaño.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbaño.FormattingEnabled = true;
            this.cmbaño.Location = new System.Drawing.Point(534, 284);
            this.cmbaño.Name = "cmbaño";
            this.cmbaño.Size = new System.Drawing.Size(63, 26);
            this.cmbaño.TabIndex = 27;
            this.cmbaño.Visible = false;
            // 
            // frmAlumno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(782, 583);
            this.ControlBox = false;
            this.Controls.Add(this.cmbaño);
            this.Controls.Add(this.cmbmes);
            this.Controls.Add(this.cmbdia);
            this.Controls.Add(this.btnConsultar);
            this.Controls.Add(this.txbcarnet);
            this.Controls.Add(this.txbaño);
            this.Controls.Add(this.txbrama);
            this.Controls.Add(this.lblcarne);
            this.Controls.Add(this.btnReinscripcion);
            this.Controls.Add(this.btnInscripcion);
            this.Controls.Add(this.btnSalirPersonal);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblslash2);
            this.Controls.Add(this.lblslash1);
            this.Controls.Add(this.lblfechanacimiento);
            this.Controls.Add(this.txbapellidoalumno);
            this.Controls.Add(this.txbnombrealumno);
            this.Controls.Add(this.lblapellidoalumno);
            this.Controls.Add(this.lblnombrealumno);
            this.Controls.Add(this.panel1);
            this.Location = new System.Drawing.Point(220, 0);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAlumno";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Alumno";
            this.Load += new System.EventHandler(this.Alumno_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnguardar;
        private System.Windows.Forms.Button btneliminar;
        private System.Windows.Forms.Button btnnuevo;
        private System.Windows.Forms.Button btnbuscar;
        private System.Windows.Forms.Button btneditar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblnombrealumno;
        private System.Windows.Forms.Label lblapellidoalumno;
        private System.Windows.Forms.TextBox txbnombrealumno;
        private System.Windows.Forms.TextBox txbapellidoalumno;
        private System.Windows.Forms.Label lblfechanacimiento;
        private System.Windows.Forms.Label lblslash1;
        private System.Windows.Forms.Label lblslash2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnSalirAlumno;
        private System.Windows.Forms.Button btnInscripcion;
        private System.Windows.Forms.Button btnReinscripcion;
        private System.Windows.Forms.Label lblcarne;
        private System.Windows.Forms.TextBox txbrama;
        private System.Windows.Forms.TextBox txbaño;
        private System.Windows.Forms.TextBox txbcarnet;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.ComboBox cmbdia;
        private System.Windows.Forms.ComboBox cmbmes;
        private System.Windows.Forms.ComboBox cmbaño;


    }
}